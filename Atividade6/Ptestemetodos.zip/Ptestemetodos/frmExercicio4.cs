﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnTotalNumericos_Click(object sender, EventArgs e)
        {
            int quantidade = 0;

            for (int letra = 0; letra < richTextTexto.Text.Length; letra++)
            {

                if (char.IsDigit(richTextTexto.Text[letra]))
                {
                    quantidade++;
                }
            }

            MessageBox.Show(quantidade.ToString());
        }

        private void btnPosicaoBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            if (richTextTexto.Text.Length > 0)
                while (!char.IsWhiteSpace(richTextTexto.Text[posicao]))
                {
                    if (posicao == richTextTexto.Text.Length -1)
                    {
                         posicao = 0;
                         break;
                    }

                     posicao++;
                }

                 MessageBox.Show(posicao.ToString());
        }

        private void btnTotAlfabeticos_Click(object sender, EventArgs e)
        {
            int quantidade = 0;

            foreach (char letra in richTextTexto.Text)
            {

                if (char.IsLetter(letra))
                {
                    quantidade++;
                }

            }

            MessageBox.Show(quantidade.ToString());
        }

    }
}
