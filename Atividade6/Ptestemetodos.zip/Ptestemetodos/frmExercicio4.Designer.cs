﻿
namespace Ptestemetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextTexto = new System.Windows.Forms.RichTextBox();
            this.btnTotalNumericos = new System.Windows.Forms.Button();
            this.btnPosicaoBranco = new System.Windows.Forms.Button();
            this.btnTotAlfabeticos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextTexto
            // 
            this.richTextTexto.Location = new System.Drawing.Point(394, 37);
            this.richTextTexto.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.richTextTexto.Name = "richTextTexto";
            this.richTextTexto.Size = new System.Drawing.Size(320, 356);
            this.richTextTexto.TabIndex = 0;
            this.richTextTexto.Text = "";
            // 
            // btnTotalNumericos
            // 
            this.btnTotalNumericos.Location = new System.Drawing.Point(83, 83);
            this.btnTotalNumericos.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnTotalNumericos.Name = "btnTotalNumericos";
            this.btnTotalNumericos.Size = new System.Drawing.Size(147, 57);
            this.btnTotalNumericos.TabIndex = 1;
            this.btnTotalNumericos.Text = "Total caracteres númericos";
            this.btnTotalNumericos.UseVisualStyleBackColor = true;
            this.btnTotalNumericos.Click += new System.EventHandler(this.btnTotalNumericos_Click);
            // 
            // btnPosicaoBranco
            // 
            this.btnPosicaoBranco.Location = new System.Drawing.Point(83, 178);
            this.btnPosicaoBranco.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnPosicaoBranco.Name = "btnPosicaoBranco";
            this.btnPosicaoBranco.Size = new System.Drawing.Size(147, 57);
            this.btnPosicaoBranco.TabIndex = 2;
            this.btnPosicaoBranco.Text = "Posição 1º caracter branco";
            this.btnPosicaoBranco.UseVisualStyleBackColor = true;
            this.btnPosicaoBranco.Click += new System.EventHandler(this.btnPosicaoBranco_Click);
            // 
            // btnTotAlfabeticos
            // 
            this.btnTotAlfabeticos.Location = new System.Drawing.Point(83, 274);
            this.btnTotAlfabeticos.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnTotAlfabeticos.Name = "btnTotAlfabeticos";
            this.btnTotAlfabeticos.Size = new System.Drawing.Size(147, 57);
            this.btnTotAlfabeticos.TabIndex = 3;
            this.btnTotAlfabeticos.Text = "Total caracteres alfabétcos";
            this.btnTotAlfabeticos.UseVisualStyleBackColor = true;
            this.btnTotAlfabeticos.Click += new System.EventHandler(this.btnTotAlfabeticos_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 529);
            this.Controls.Add(this.btnTotAlfabeticos);
            this.Controls.Add(this.btnPosicaoBranco);
            this.Controls.Add(this.btnTotalNumericos);
            this.Controls.Add(this.richTextTexto);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frmExercicio4";
            this.Text = "frmexercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextTexto;
        private System.Windows.Forms.Button btnTotalNumericos;
        private System.Windows.Forms.Button btnPosicaoBranco;
        private System.Windows.Forms.Button btnTotAlfabeticos;
    }
}