﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();

        }

        Form aberto = new Form();

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Entrei no copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Entrei no colar");

        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // chamar o formulário
            
            if (aberto != null)
                aberto.Close();

            frmExercicio2 objFrm2 = new frmExercicio2();
            objFrm2.MdiParent = this; // componente atual no caso o frmPrincipal
            objFrm2.WindowState = FormWindowState.Maximized;
            aberto = objFrm2;
            objFrm2.Show();
                   
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (aberto != null)
                aberto.Close();

            frmExercicio3 objFrm3 = new frmExercicio3();
            objFrm3.MdiParent = this; // componente atual no caso o frmPrincipal
            objFrm3.WindowState = FormWindowState.Maximized;
            aberto = objFrm3;
            objFrm3.Show();
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (aberto != null)
                aberto.Close();

            frmExercicio4 objFrm4 = new frmExercicio4();
            objFrm4.MdiParent = this; // componente atual no caso o frmPrincipal
            objFrm4.WindowState = FormWindowState.Maximized;
            aberto = objFrm4;
            objFrm4.Show();
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (aberto != null)
                aberto.Close();

            frmExercicio5 objFrm5 = new frmExercicio5();
            objFrm5.MdiParent = this; // componente atual no caso o frmPrincipal
            objFrm5.WindowState = FormWindowState.Maximized;
            aberto = objFrm5;
            objFrm5.Show();
        }

    }
}
