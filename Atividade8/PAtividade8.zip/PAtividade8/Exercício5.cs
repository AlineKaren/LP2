﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PAtividade8
{
    public partial class Exercício5 : Form
    {
        public Exercício5()
        {
            InitializeComponent();
        }

        private void btnImNomes_Click(object sender, EventArgs e)
        {
            //Criar uma lista e adicionar os nomes:
            List<string> Nomes = new List<string>()
            {
                "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais"
            };
            //Remover um determinado nome:
            Nomes.Remove("Otávio");

            // Imprimir a lista de nomes:

            string saída = "";

            foreach(string nome in Nomes)
            {
                saída += nome + "\n";
            }

            MessageBox.Show(saída);
            
        }
    }
}
