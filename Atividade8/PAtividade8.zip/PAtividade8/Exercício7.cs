﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class Exercício7 : Form
    {
        public Exercício7()
        {
            InitializeComponent();
        }


        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[5];
            int[] letras = new int[nomes.Length];

            for( int i = 0; i<nomes.Length; i++)
            {
                var leitura = Interaction.InputBox("Entre com o #() nome", "Leitura de Nomes");

                // Se o nome for inválido
                if (string.IsNullOrEmpty(leitura))
                {
                    MessageBox.Show("Nome Inválido");
                    i--;
                    continue;
                }
                //Se sucesso, passo o nome;
                nomes[i] = leitura;
                int quantidade = 0;

               foreach(char letra in nomes[i])
                {
                    if (letra != ' ')
                        quantidade++;
                }

                //Adciono a quantidade de 
                letras[i] = quantidade;

            }

            //Gerar saida:
            for (int i = 0; i<nomes.Length; i++)
            {
                listBoxNomes.Items.Add($" o nome: {nomes[i]} tem { letras[i]} caracteres \n");

            }

        }
    }
}
