﻿
namespace P.Pesoideal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Altura = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioMulher = new System.Windows.Forms.RadioButton();
            this.radioHomem = new System.Windows.Forms.RadioButton();
            this.buttonCalcular = new System.Windows.Forms.Button();
            this.maskedTextBoxAltura = new System.Windows.Forms.MaskedTextBox();
            this.PesoAtual = new System.Windows.Forms.Label();
            this.buttonLimpar = new System.Windows.Forms.Button();
            this.buttonSair = new System.Windows.Forms.Button();
            this.maskedTextBoxPesoAtual = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Altura
            // 
            this.Altura.AutoSize = true;
            this.Altura.Location = new System.Drawing.Point(134, 210);
            this.Altura.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Altura.Name = "Altura";
            this.Altura.Size = new System.Drawing.Size(109, 16);
            this.Altura.TabIndex = 0;
            this.Altura.Text = "Altura(metros):";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioMulher);
            this.groupBox1.Controls.Add(this.radioHomem);
            this.groupBox1.Location = new System.Drawing.Point(339, 75);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(280, 86);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo:";
            // 
            // radioMulher
            // 
            this.radioMulher.AutoSize = true;
            this.radioMulher.Location = new System.Drawing.Point(163, 39);
            this.radioMulher.Margin = new System.Windows.Forms.Padding(4);
            this.radioMulher.Name = "radioMulher";
            this.radioMulher.Size = new System.Drawing.Size(89, 36);
            this.radioMulher.TabIndex = 4;
            this.radioMulher.Text = "\r\nFeminino";
            this.radioMulher.UseVisualStyleBackColor = true;
            // 
            // radioHomem
            // 
            this.radioHomem.AutoSize = true;
            this.radioHomem.Checked = true;
            this.radioHomem.Location = new System.Drawing.Point(9, 23);
            this.radioHomem.Margin = new System.Windows.Forms.Padding(4);
            this.radioHomem.Name = "radioHomem";
            this.radioHomem.Size = new System.Drawing.Size(96, 52);
            this.radioHomem.TabIndex = 3;
            this.radioHomem.TabStop = true;
            this.radioHomem.Text = "\r\n\r\nMasculino";
            this.radioHomem.UseVisualStyleBackColor = true;
            // 
            // buttonCalcular
            // 
            this.buttonCalcular.Location = new System.Drawing.Point(243, 294);
            this.buttonCalcular.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCalcular.Name = "buttonCalcular";
            this.buttonCalcular.Size = new System.Drawing.Size(161, 48);
            this.buttonCalcular.TabIndex = 2;
            this.buttonCalcular.Text = "Calcular";
            this.buttonCalcular.UseVisualStyleBackColor = true;
            this.buttonCalcular.Click += new System.EventHandler(this.buttonCalcular_Click);
            // 
            // maskedTextBoxAltura
            // 
            this.maskedTextBoxAltura.Location = new System.Drawing.Point(111, 240);
            this.maskedTextBoxAltura.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBoxAltura.Name = "maskedTextBoxAltura";
            this.maskedTextBoxAltura.Size = new System.Drawing.Size(172, 22);
            this.maskedTextBoxAltura.TabIndex = 4;
            this.maskedTextBoxAltura.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBoxAltura_MaskInputRejected);
            // 
            // PesoAtual
            // 
            this.PesoAtual.AutoSize = true;
            this.PesoAtual.Location = new System.Drawing.Point(396, 210);
            this.PesoAtual.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PesoAtual.Name = "PesoAtual";
            this.PesoAtual.Size = new System.Drawing.Size(119, 16);
            this.PesoAtual.TabIndex = 5;
            this.PesoAtual.Text = "Peso Atual(Kg.):";
            // 
            // buttonLimpar
            // 
            this.buttonLimpar.Location = new System.Drawing.Point(143, 350);
            this.buttonLimpar.Margin = new System.Windows.Forms.Padding(4);
            this.buttonLimpar.Name = "buttonLimpar";
            this.buttonLimpar.Size = new System.Drawing.Size(161, 48);
            this.buttonLimpar.TabIndex = 7;
            this.buttonLimpar.Text = "Limpar";
            this.buttonLimpar.UseVisualStyleBackColor = true;
            this.buttonLimpar.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonSair
            // 
            this.buttonSair.Location = new System.Drawing.Point(339, 350);
            this.buttonSair.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSair.Name = "buttonSair";
            this.buttonSair.Size = new System.Drawing.Size(161, 48);
            this.buttonSair.TabIndex = 8;
            this.buttonSair.Text = "Sair";
            this.buttonSair.UseVisualStyleBackColor = true;
            this.buttonSair.Click += new System.EventHandler(this.button2_Click);
            // 
            // maskedTextBoxPesoAtual
            // 
            this.maskedTextBoxPesoAtual.Location = new System.Drawing.Point(369, 240);
            this.maskedTextBoxPesoAtual.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBoxPesoAtual.Name = "maskedTextBoxPesoAtual";
            this.maskedTextBoxPesoAtual.Size = new System.Drawing.Size(172, 22);
            this.maskedTextBoxPesoAtual.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(282, 26);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 16);
            this.label3.TabIndex = 10;
            this.label3.Text = "Peso Ideal";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 463);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.maskedTextBoxPesoAtual);
            this.Controls.Add(this.buttonSair);
            this.Controls.Add(this.buttonLimpar);
            this.Controls.Add(this.PesoAtual);
            this.Controls.Add(this.maskedTextBoxAltura);
            this.Controls.Add(this.buttonCalcular);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Altura);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Altura;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioMulher;
        private System.Windows.Forms.RadioButton radioHomem;
        private System.Windows.Forms.Button buttonCalcular;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxAltura;
        private System.Windows.Forms.Label PesoAtual;
        private System.Windows.Forms.Button buttonLimpar;
        private System.Windows.Forms.Button buttonSair;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxPesoAtual;
        private System.Windows.Forms.Label label3;
    }
}

