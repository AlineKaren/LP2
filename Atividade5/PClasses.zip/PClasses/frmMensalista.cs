﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            //set
            objMensalista.Matricula = Convert.ToInt32(textMatricula.Text);
            objMensalista.NomeEmpregado = textNome.Text;
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(textData.Text);// dd/mm/yyyy
            objMensalista.SalarioMensal = Convert.ToDouble(textSalario.Text); 

            //get 
            MessageBox.Show("Matrícula    : " + objMensalista.Matricula + "\n" +
                            "Nome         : " + objMensalista.NomeEmpregado + "\n"+
                            "Data Entrada : " + objMensalista.DataEntradaEmpresa.ToShortDateString() + "\n"+
                            "Salrio Mensal: " + objMensalista.SalarioBruto() + "\n"+
                            "Tempo Empresa (dias): " + objMensalista.TempoTrabalho());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(Convert.ToInt32(textMatricula.Text), 
                textNome.Text, Convert.ToDateTime(textData.Text), Convert.ToDouble(textSalario.Text));
            
            
            //get
            MessageBox.Show("Matrícula    : " + objMensalista.Matricula + "\n" +
                            "Nome         : " + objMensalista.NomeEmpregado + "\n" +
                            "Data Entrada : " + objMensalista.DataEntradaEmpresa.ToShortDateString() + "\n" +
                            "Salrio Mensal: " + objMensalista.SalarioBruto() + "\n" +
                            "Tempo Empresa (dias): " + objMensalista.TempoTrabalho());

        }
    }
}
