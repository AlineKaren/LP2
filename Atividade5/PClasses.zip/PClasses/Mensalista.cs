﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    class Mensalista : Empregado
    {
      
         
        public double SalarioMensal { get; set; }


        public Mensalista() //  o construtor tem o nome da classe e ele fica vazio
        {

        }

        public Mensalista (int matx, string nomex, DateTime datx, double salariox)
        {
            Matricula = matx;
            NomeEmpregado = nomex;
            DataEntradaEmpresa = datx;
            SalarioMensal = salariox;
        }


        //sobreescrevendo o método

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }

    }

}
