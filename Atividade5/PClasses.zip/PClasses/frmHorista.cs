﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void frmHorista_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void buttonInstanciarHorista_Click(object sender, EventArgs e)
        {
            //Empregado objEmpregado = new Empregado();
            //não pode instanciar obejto de classe abstrata

                // criando o objeto, instancando o obejto
                Horista objHorista = new Horista();

            objHorista.NomeEmpregado = textBoxNome.Text;
            objHorista.Matricula = Convert.ToInt32(textBoxMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(textBoxSalHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(textBoxNumHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(textBoxDatEntrEmpresa.Text);
            objHorista.DiasFalta = Convert.ToInt32(textBoxDiasFalta.Text);

            MessageBox.Show("Nome: " + objHorista.NomeEmpregado + "\n" +
                            "Matrícula        : " + objHorista.Matricula + "\n" +
                            "Tempo Trabalhado: " + objHorista.TempoTrabalho().ToString()
                + "\n" + "Salario: " + objHorista.SalarioBruto().ToString("N2"));


        }
    }
}
