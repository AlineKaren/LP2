﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class Exercício2 : Form
    {
        public Exercício2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (int.TryParse(txtN.Text, out int N))
            {
                if (N > 0)
                {
                    double H = 1;
                    while (N > 0)
                    {
                        H += 1.0 / N;

                        N--;
                    }
                    MessageBox.Show(H.ToString("N2"));
                    txtN.Text = H.ToString();
                }
                else
                {
                    MessageBox.Show(" Atenção!!! O número precisa ser maior do que 0.");
                }
            }
            else
            {
                MessageBox.Show("Por favor, coloque apenas números!");
            }
        }
                  
    }
}
