﻿
namespace Atividade7
{
    partial class Exercício1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btnNumBranco = new System.Windows.Forms.Button();
            this.btnNumLetras = new System.Windows.Forms.Button();
            this.btnNumParesdeLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(265, 84);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(5, 2, 5, 2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(376, 291);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // btnNumBranco
            // 
            this.btnNumBranco.Location = new System.Drawing.Point(55, 104);
            this.btnNumBranco.Margin = new System.Windows.Forms.Padding(5, 2, 5, 2);
            this.btnNumBranco.Name = "btnNumBranco";
            this.btnNumBranco.Size = new System.Drawing.Size(148, 53);
            this.btnNumBranco.TabIndex = 1;
            this.btnNumBranco.Text = "Nº espaços em branco";
            this.btnNumBranco.UseVisualStyleBackColor = true;
            this.btnNumBranco.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnNumLetras
            // 
            this.btnNumLetras.Location = new System.Drawing.Point(55, 199);
            this.btnNumLetras.Margin = new System.Windows.Forms.Padding(5, 2, 5, 2);
            this.btnNumLetras.Name = "btnNumLetras";
            this.btnNumLetras.Size = new System.Drawing.Size(148, 53);
            this.btnNumLetras.TabIndex = 2;
            this.btnNumLetras.Text = "Nº de letras R";
            this.btnNumLetras.UseVisualStyleBackColor = true;
            this.btnNumLetras.Click += new System.EventHandler(this.btnNumLetras_Click);
            // 
            // btnNumParesdeLetras
            // 
            this.btnNumParesdeLetras.Location = new System.Drawing.Point(55, 289);
            this.btnNumParesdeLetras.Margin = new System.Windows.Forms.Padding(5, 2, 5, 2);
            this.btnNumParesdeLetras.Name = "btnNumParesdeLetras";
            this.btnNumParesdeLetras.Size = new System.Drawing.Size(148, 53);
            this.btnNumParesdeLetras.TabIndex = 3;
            this.btnNumParesdeLetras.Text = "Nº de pares de letras";
            this.btnNumParesdeLetras.UseVisualStyleBackColor = true;
            this.btnNumParesdeLetras.Click += new System.EventHandler(this.btnNumParesdeLetras_Click);
            // 
            // Exercício1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(751, 450);
            this.Controls.Add(this.btnNumParesdeLetras);
            this.Controls.Add(this.btnNumLetras);
            this.Controls.Add(this.btnNumBranco);
            this.Controls.Add(this.richTextBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 2, 5, 2);
            this.Name = "Exercício1";
            this.Text = "Exercício1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btnNumBranco;
        private System.Windows.Forms.Button btnNumLetras;
        private System.Windows.Forms.Button btnNumParesdeLetras;
    }
}

