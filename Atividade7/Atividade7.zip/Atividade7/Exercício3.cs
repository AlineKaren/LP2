﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class Exercício3 : Form
    {
        public Exercício3()
        {
            InitializeComponent();
        }

        private void Exercício3_Load(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string texto = txtPalindromo.Text;

            //Remover os espaços
            texto = texto.Replace(" ", "");

            //Dwixar em maiuculo
            texto = texto.ToUpper();

            //Inverter
            string textoInvertido = new string(texto.Reverse().ToArray());

            //Comparar
            if (texto == textoInvertido)
            {
                MessageBox.Show("É Palíndromo!");
            }
            else
                MessageBox.Show("Não é Palíndromo!!!");
        }
    }
}
