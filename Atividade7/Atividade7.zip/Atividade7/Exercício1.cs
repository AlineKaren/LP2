﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class Exercício1 : Form
    {
        public Exercício1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int quantidade = 0;

            for (int espacobranco = 0; espacobranco < richTextBox1.Text.Length; espacobranco++)
            {

                if (char.IsWhiteSpace(richTextBox1.Text[espacobranco]))
                {
                    quantidade++;
                }
            }

            MessageBox.Show(quantidade.ToString());
        }

        private void btnNumLetras_Click(object sender, EventArgs e)
        {

            int R = 0;
            
            foreach(char letra in richTextBox1.Text)
            {
                if (char.ToUpper(letra)== 'R')
                {
                    R++;
                }
            }

            MessageBox.Show(R.ToString());
        }

        private void btnNumParesdeLetras_Click(object sender, EventArgs e)
        {
            int Pares = 0;
            string texto = richTextBox1.Text;

            for (int letra = 0; letra<texto.Length-1; letra++)
            {
                if (texto[letra] == texto[letra+1])
                {
                    Pares++;
                }
            }

            MessageBox.Show(Pares.ToString());
        }
    }
}
