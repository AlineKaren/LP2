﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        Form aberto = new Form();

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (aberto != null)
                aberto.Close();

            Exercício1 objFrm1 = new Exercício1();
            objFrm1.MdiParent = this; // componente atual no caso o frmPrincipal
            objFrm1.WindowState = FormWindowState.Maximized;
            aberto = objFrm1;
            objFrm1.Show();
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (aberto != null)
                aberto.Close();

            Exercício2 objFrm2 = new Exercício2();
            objFrm2.MdiParent = this; // componente atual no caso o frmPrincipal
            objFrm2.WindowState = FormWindowState.Maximized;
            aberto = objFrm2;
            objFrm2.Show();
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (aberto != null)
                aberto.Close();

            Exercício3 objFrm3 = new Exercício3();
            objFrm3.MdiParent = this; // componente atual no caso o frmPrincipal
            objFrm3.WindowState = FormWindowState.Maximized;
            aberto = objFrm3;
            objFrm3.Show();
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           if (aberto != null)
                aberto.Close();

            Exercício4 objFrm4 = new Exercício4();
            objFrm4.MdiParent = this; // componente atual no caso o frmPrincipal
            objFrm4.WindowState = FormWindowState.Maximized;
            aberto = objFrm4;
            objFrm4.Show();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
