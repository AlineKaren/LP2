﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P.LadosTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBoxLado1_KeyPress(object sender, KeyPressEventArgs e)
        {
                if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
                {
                    MessageBox.Show("Digite Somente Números", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    e.Handled = true;
                    return;
                }
            }

        private void textBoxLado2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Digite Somente Números", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void textBoxLado3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("Digite Somente Números", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBoxLado1.Clear();
            textBoxLado2.Clear();
            textBoxLado3.Clear();
        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonTestarValores_Click(object sender, EventArgs e)
        {
            int Lado1, Lado2, Lado3;

            int.TryParse(textBoxLado1.Text, out Lado1);
            int.TryParse(textBoxLado2.Text, out Lado2);
            int.TryParse(textBoxLado3.Text, out Lado3);

            {
                if (textBoxLado1.Text != "")
                    if (textBoxLado2.Text != "")
                        if (textBoxLado3.Text != "")

                            if (Lado1 < (Lado2 + Lado3) && Lado2 < (Lado1 + Lado3) && Lado3 < (Lado1 + Lado2) && Lado1 > Math.Abs(Lado2 - Lado3) &&
                Lado2 > Math.Abs(Lado1 - Lado3) &&
                Lado3 > Math.Abs(Lado2 - Lado3))

                                if (Lado1 == Lado2 && Lado2 == Lado3)
                                {
                                    MessageBox.Show("Triângulo Equilátero.");
                                }
                                else if (Lado1 == Lado2 || Lado2 == Lado3 || Lado1 == Lado3)
                                {
                                    MessageBox.Show("Triângulo Isóceles.");
                                }
                                else
                                {
                                    MessageBox.Show("Triângulo Escaleno.");
                                }
                            else
                            {
                                MessageBox.Show("Não é um Triângulo.");
                            }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            buttonTestarValores.Enabled = false;
        }

        private void validarCampo()
        {
            var vr = !string.IsNullOrEmpty(textBoxLado1.Text) && !string.IsNullOrEmpty(textBoxLado2.Text) && !string.IsNullOrEmpty(textBoxLado3.Text);
            buttonTestarValores.Enabled = vr;
        }

        private void textBoxLado1_TextChanged(object sender, EventArgs e)
        {
            validarCampo();
        }

        private void textBoxLado2_TextChanged(object sender, EventArgs e)
        {
            validarCampo();
        }

        private void textBoxLado3_TextChanged(object sender, EventArgs e)
        {
            validarCampo();
        }
    }
}

