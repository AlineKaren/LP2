﻿
namespace P.LadosTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxLado1 = new System.Windows.Forms.TextBox();
            this.textBoxLado2 = new System.Windows.Forms.TextBox();
            this.textBoxLado3 = new System.Windows.Forms.TextBox();
            this.buttonTestarValores = new System.Windows.Forms.Button();
            this.buttonLimpar = new System.Windows.Forms.Button();
            this.buttonSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(210, 33);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Triângulo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(60, 130);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lado 1: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(60, 202);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Lado 2:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 272);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Lado 3: ";
            // 
            // textBoxLado1
            // 
            this.textBoxLado1.Location = new System.Drawing.Point(141, 127);
            this.textBoxLado1.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxLado1.Name = "textBoxLado1";
            this.textBoxLado1.Size = new System.Drawing.Size(234, 22);
            this.textBoxLado1.TabIndex = 4;
            this.textBoxLado1.TextChanged += new System.EventHandler(this.textBoxLado1_TextChanged);
            this.textBoxLado1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxLado1_KeyPress);
            // 
            // textBoxLado2
            // 
            this.textBoxLado2.Location = new System.Drawing.Point(140, 200);
            this.textBoxLado2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxLado2.Name = "textBoxLado2";
            this.textBoxLado2.Size = new System.Drawing.Size(234, 22);
            this.textBoxLado2.TabIndex = 5;
            this.textBoxLado2.TextChanged += new System.EventHandler(this.textBoxLado2_TextChanged);
            this.textBoxLado2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxLado2_KeyPress);
            // 
            // textBoxLado3
            // 
            this.textBoxLado3.Location = new System.Drawing.Point(141, 269);
            this.textBoxLado3.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxLado3.Name = "textBoxLado3";
            this.textBoxLado3.Size = new System.Drawing.Size(234, 22);
            this.textBoxLado3.TabIndex = 6;
            this.textBoxLado3.TextChanged += new System.EventHandler(this.textBoxLado3_TextChanged);
            this.textBoxLado3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxLado3_KeyPress);
            // 
            // buttonTestarValores
            // 
            this.buttonTestarValores.Location = new System.Drawing.Point(206, 329);
            this.buttonTestarValores.Name = "buttonTestarValores";
            this.buttonTestarValores.Size = new System.Drawing.Size(119, 39);
            this.buttonTestarValores.TabIndex = 7;
            this.buttonTestarValores.Text = "Testar Valores";
            this.buttonTestarValores.UseVisualStyleBackColor = true;
            this.buttonTestarValores.Click += new System.EventHandler(this.buttonTestarValores_Click);
            // 
            // buttonLimpar
            // 
            this.buttonLimpar.Location = new System.Drawing.Point(159, 383);
            this.buttonLimpar.Name = "buttonLimpar";
            this.buttonLimpar.Size = new System.Drawing.Size(101, 39);
            this.buttonLimpar.TabIndex = 8;
            this.buttonLimpar.Text = "Limpar";
            this.buttonLimpar.UseVisualStyleBackColor = true;
            this.buttonLimpar.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonSair
            // 
            this.buttonSair.Location = new System.Drawing.Point(273, 383);
            this.buttonSair.Name = "buttonSair";
            this.buttonSair.Size = new System.Drawing.Size(101, 39);
            this.buttonSair.TabIndex = 9;
            this.buttonSair.Text = "Sair";
            this.buttonSair.UseVisualStyleBackColor = true;
            this.buttonSair.Click += new System.EventHandler(this.buttonSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 496);
            this.Controls.Add(this.buttonSair);
            this.Controls.Add(this.buttonLimpar);
            this.Controls.Add(this.buttonTestarValores);
            this.Controls.Add(this.textBoxLado3);
            this.Controls.Add(this.textBoxLado2);
            this.Controls.Add(this.textBoxLado1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxLado1;
        private System.Windows.Forms.TextBox textBoxLado2;
        private System.Windows.Forms.TextBox textBoxLado3;
        private System.Windows.Forms.Button buttonTestarValores;
        private System.Windows.Forms.Button buttonLimpar;
        private System.Windows.Forms.Button buttonSair;
    }
}

