﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P.Calculadora
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado;

        private void button6_Click(object sender, EventArgs e)
        {
            textNum1.Clear();
            textNum2.Clear();
            textResultado.Clear();

            textNum1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textNum1.Text, out Numero1) &&
             double.TryParse(textNum2.Text, out Numero2))
            {

                Resultado = Numero1 + Numero2;
                textResultado.Text = Resultado.ToString();
            }

            else
                MessageBox.Show("Números inválidos!!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textNum1.Text, out Numero1) &&
                double.TryParse(textNum2.Text, out Numero2))
            {

                Resultado = Numero1 - Numero2;
                textResultado.Text = Resultado.ToString();
            }

            else
                MessageBox.Show("Números inválidos!!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textNum1.Text, out Numero1) &&
               double.TryParse(textNum2.Text, out Numero2))
            {

                Resultado = Numero1 * Numero2;
                textResultado.Text = Resultado.ToString();
            }

            else
                MessageBox.Show("Números inválidos!!");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textNum1.Text, out Numero1) &&
               double.TryParse(textNum2.Text, out Numero2))
            {
                if (Numero2 == 0)
                    MessageBox.Show("não pode dividir por zero!!!");
                else
                {

                    Resultado = Numero1 / Numero2;
                    textResultado.Text = Resultado.ToString();
                }
            }

            else
                MessageBox.Show("Números inválidos!!");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
